# HZMetro_OD_15min — 杭州地铁 OD 矩阵数据集

## 概述

杭州地铁 2019 年 1 月的 OD（起讫点）客流量矩阵。从 25 天 AFC 刷卡记录中通过 userID 匹配构建，15 分钟粒度。

## 文件清单

| 文件 | 形状 | 说明 |
|------|------|------|
| `train_data.npy` | (1440, 81, 81) | 训练集：前 60% 时间步 |
| `val_data.npy` | (480, 81, 81) | 验证集：中间 20% |
| `test_data.npy` | (480, 81, 81) | 测试集：最后 20% |
| `train_timestamps.npy` | (1440, 2) | 每步时间戳 [time_of_day, day_of_week] |
| `val_timestamps.npy` | (480, 2) | 同上 |
| `test_timestamps.npy` | (480, 2) | 同上 |
| `adj_mx.npy` | (81, 81) | 邻接矩阵（线路拓扑） |
| `meta.json` | — | 元信息 |

## 数据来源

原始 AFC 记录 `C:\subwayDataset\2019_1_杭州\Metro_train\record_2019-01-*.csv`：
- 时间范围：2019-01-01 ~ 2019-01-25（25 天）
- 总记录：约 60M 条
- 聚合粒度：15 分钟

## OD 匹配方法

```
对每个 CSV 文件:
  1. 按 userID + time 排序
  2. 用 shift(-1) 匹配相邻的进站(1)和出站(0)记录
  3. 要求: 同 userID, status=1 → next_status=0
  4. 排除 payType=3 的记录
  5. 按出发时间(time_slot)聚合到 15min 窗口
  6. 累加到 OD[t, origin, destination]
```

相比参考数据（`C:\subwayDataset\2019_1_杭州\Metro_train\od_flow.npy`），本数据集丢失约 22-28% 的客流，主要发生在夜间和非高峰时段。原因是 shift 匹配法在记录被 payType 过滤打断时会失败。

## 字段说明

`OD[t, o, d]` = 第 t 个 15 分钟窗口内，从 o 站进入、d 站出去的乘客数。

时间戳同站点数据集。

## 统计数据

| 统计量 | 值 |
|--------|------|
| 站点数 | 81 |
| OD 对 | 81 × 81 = 6561 |
| 时间步 | 2400（25 天 × 96 步/天） |
| 零值占比 | 68.3% |
| 均值 | 1.40 人/OD对/步 |
| 标准差 | 4.52 |
| 最大值 | 482 |

## 使用方式

OD 预测任务，用于 M3Net+ / M3Net-BG 等模型：

```python
# 独立训练 (非 BasicTS，因输出维度 N≠M)
python experiments/run_od_v2.py
```

模型输入：站点流（OD 的行和） + 历史 OD 切片，输出：未来 OD 矩阵 `[B, out_len, N, N]`。

## 注意事项

1. **OD 匹配丢失 ~25% 客流**：shift 匹配法在 payType=3 过滤后不完美，但主要的时空模式保留。如需要更精确的 OD 数据，使用 `C:\subwayDataset\2019_1_杭州\Metro_train\od_flow.npy`（参考数据）
2. **对角线非零**：约 54K 条 trip 的起终点相同，可能是短时返回或匹配误差
3. 68% 的 OD 对在任意 15 分钟内流量为 0 — 这是一个极度稀疏的数据集
4. 最新模型 M3Net+ (v2) 在该数据集上达到 **MAE=0.9569**
